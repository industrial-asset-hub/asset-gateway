/* extendbuf.h -- Manage a dynamically-alloicated buffer

   Copyright (C) 2004-2022 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#ifndef INC_EXTENDBUF_H
# define INC_EXTENDBUF_H 1

void *extendbuf(void* existing, size_t wanted, size_t *allocated);
void *xextendbuf(void* existing, size_t wanted, size_t *allocated);


#endif
