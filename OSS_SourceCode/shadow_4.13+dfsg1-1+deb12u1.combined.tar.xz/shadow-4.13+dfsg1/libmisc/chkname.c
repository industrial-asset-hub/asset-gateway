/*
 * SPDX-FileCopyrightText: 1990 - 1994, Julianne Frances Haugh
 * SPDX-FileCopyrightText: 1996 - 2000, Marek Michałkiewicz
 * SPDX-FileCopyrightText: 2001 - 2005, Tomasz Kłoczko
 * SPDX-FileCopyrightText: 2005 - 2008, Nicolas François
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/*
 * is_valid_user_name(), is_valid_group_name() - check the new user/group
 * name for validity;
 * return values:
 *   true  - OK
 *   false - bad name
 */

#include <config.h>

#ident "$Id$"

#include <ctype.h>
#include "defines.h"
#include "chkname.h"

int allow_bad_names = false;

static bool is_valid_name (const char *name)
{
	if (allow_bad_names) {
		return true;
	}

	/*
	 * POSIX indicate that usernames are composed of characters from the
	 * portable filename character set [A-Za-z0-9._-], and that the hyphen
	 * should not be used as the first character of a portable user name.
	 *
	 * Allow more relaxed user/group names in Debian -- ^[^-~+:,\s][^:,\s]*$
	 */
	if (   ('\0' == *name)
	    || ('-'  == *name)
	    || ('~'  == *name)
	    || ('+'  == *name)) {
		return false;
	}
	do {
		if ((':' == *name) || (',' == *name) || isspace(*name)) {
			return false;
		}
		name++;
	} while ('\0' != *name);

	return true;
}

bool is_valid_user_name (const char *name)
{
	/*
	 * User names are limited by whatever utmp can
	 * handle.
	 */
	if (strlen (name) > USER_NAME_MAX_LENGTH) {
		return false;
	}

	return is_valid_name (name);
}

bool is_valid_group_name (const char *name)
{
	/*
	 * Arbitrary limit for group names.
	 * HP-UX 10 limits to 16 characters
	 */
	if (   (GROUP_NAME_MAX_LENGTH > 0)
	    && (strlen (name) > GROUP_NAME_MAX_LENGTH)) {
		return false;
	}

	return is_valid_name (name);
}

