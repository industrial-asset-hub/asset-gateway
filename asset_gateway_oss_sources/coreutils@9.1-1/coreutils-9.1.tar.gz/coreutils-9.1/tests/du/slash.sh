#!/bin/sh
# 'du /' would omit the '/' on the last line.

# Copyright (C) 2003-2022 Free Software Foundation, Inc.

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

. "${srcdir=.}/tests/init.sh"; path_prepend_ ./src
print_ver_ du
require_readable_root_


du --exclude='[^/]*' -x / > out-t || fail=1
sed 's/^[0-9][0-9]*	//' out-t > out
rm -f out-t
cat <<\EOF > exp
/
EOF

compare exp out || fail=1

Exit $fail
