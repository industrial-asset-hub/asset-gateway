#!/usr/bin/perl

=head1 NAME

Debconf::Format::822 - RFC-822-ish output format

=cut

package Debconf::Format::822;
use warnings;
use strict;
use base 'Debconf::Format';

=head1 DESCRIPTION

This formats data in a vaguely RFC-822-ish way.

=cut

# Not needed.
sub beginfile {}
sub endfile {}

sub read {
	my $this=shift;
	my $fh=shift;

	# Make sure it's sane.
	local $/="\n";

	my $name;
	my %ret=(
		owners => {},
		fields => {},
		variables => {},
		flags => {},
	);

	my $invars=0;
	my $line;
	while ($line = <$fh>) {
		chomp $line;
		last if $line eq ''; # blank line is our record delimiter

		# Process variables.
		if ($invars) {
			if ($line =~ /^\s/) {
				$line =~ s/^\s+//;
				my ($var, $value)=split(/\s*=\s?/, $line, 2);
				$value=~s/\\n/\n/g;
				$ret{variables}->{$var}=$value;
				next;
			}
			else {
				$invars=0;
			}
		}

		# Process the main structure.
		my ($key, $value)=split(/:\s?/, $line, 2);
		$key=lc($key);
		if ($key eq 'owners') {
			foreach my $owner (split(/,\s+/, $value)) {
				$ret{owners}->{$owner}=1;
			}
		}
		elsif ($key eq 'flags') {
			foreach my $flag (split(/,\s+/, $value)) {
				$ret{flags}->{$flag}='true';
			}
		}
		elsif ($key eq 'variables') {
			$invars=1;
		}
		elsif ($key eq 'name') {
			$name=$value;
		}
		elsif (length $key) {
			$value=~s/\\n/\n/g;
			$ret{fields}->{$key}=$value;
		}
	}

	return unless defined $name;
	return $name, \%ret;
}

sub write {
	my $this=shift;
	my $fh=shift;
	my %data=%{shift()};
	my $name=shift;

	print $fh "Name: $name\n" or return;
	foreach my $field (sort keys %{$data{fields}}) {
		my $val=$data{fields}->{$field};
		$val=~s/\n/\\n/g;
		print $fh ucfirst($field).": $val\n" or return;
	}
	if (keys %{$data{owners}}) {
		print $fh "Owners: ".join(", ", sort keys(%{$data{owners}}))."\n"
			or return;
	}
	if (grep { $data{flags}->{$_} eq 'true' } keys %{$data{flags}}) {
		print $fh "Flags: ".join(", ",
			grep { $data{flags}->{$_} eq 'true' }
				sort keys(%{$data{flags}}))."\n"
			or return;
	}
	if (keys %{$data{variables}}) {
		print $fh "Variables:\n" or return;
		foreach my $var (sort keys %{$data{variables}}) {
			my $val=$data{variables}->{$var};
			$val=~s/\n/\\n/g;
			print $fh " $var = $val\n" or return;
		}
	}
	print $fh "\n" or return; # end of record delimiter
	return 1;
}

=head1 AUTHOR

Joey Hess <joeyh@debian.org>

=cut

1
